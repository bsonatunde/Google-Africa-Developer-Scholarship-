package com.freedom.googlescholarshipproject.fragment

import androidx.fragment.app.Fragment

open class AppFragment : Fragment() {
    open fun onResumeFragment() {}
}